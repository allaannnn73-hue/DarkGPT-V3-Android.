package com.malanb4u.darkgpt;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xff090d17);
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(8, 8, 8, 8);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("DarkGPT V3"); title.setTextColor(0xffffffff); title.setTextSize(15);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button local = new Button(this); local.setText("Données");
        Button chat = new Button(this); chat.setText("Chat IA");
        bar.addView(local); bar.addView(chat);
        root.addView(bar);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.addJavascriptInterface(new AI(), "DarkGPTBridge");
        web.setWebViewClient(new WebViewClient());
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        local.setOnClickListener(v -> web.loadUrl("file:///android_asset/index.html"));
        chat.setOnClickListener(v -> web.loadUrl("file:///android_asset/chat.html"));
        web.loadUrl("file:///android_asset/chat.html");
    }
    public class AI {
        @JavascriptInterface public void send(String apiKey, String model, String messagesJson) {
            new Thread(() -> {
                String result;
                try {
                    if (apiKey == null || !apiKey.startsWith("sk-or-")) throw new Exception("Entre une clé API OpenRouter valide.");
                    JSONArray messages = new JSONArray(messagesJson);
                    JSONObject payload = new JSONObject();
                    payload.put("model", model);
                    payload.put("messages", messages);
                    payload.put("max_tokens", 800);
                    HttpURLConnection conn = (HttpURLConnection)new URL("https://openrouter.ai/api/v1/chat/completions").openConnection();
                    conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(90000);
                    conn.setRequestProperty("Authorization", "Bearer " + apiKey);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("HTTP-Referer", "https://darkgptfree.com");
                    conn.setRequestProperty("X-Title", "DarkGPT V3");
                    conn.setDoOutput(true);
                    try(OutputStream out=conn.getOutputStream()) {out.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
                    int status=conn.getResponseCode();
                    InputStream stream = status < 400 ? conn.getInputStream() : conn.getErrorStream();
                    byte[] bytes = new byte[0];
                    if(stream!=null) { java.io.ByteArrayOutputStream b=new java.io.ByteArrayOutputStream(); byte[] chunk=new byte[4096];int n;while((n=stream.read(chunk))!=-1 && b.size()<200000){b.write(chunk,0,n);}bytes=b.toByteArray();stream.close();}
                    JSONObject response = new JSONObject(new String(bytes,StandardCharsets.UTF_8));
                    if(status>=400) throw new Exception(response.optJSONObject("error")!=null ? response.getJSONObject("error").optString("message","Erreur API "+status) : "Erreur API "+status);
                    result=response.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content","Réponse vide.");
                } catch(Exception ex) { result="ERREUR : " + ex.getMessage(); }
                final String answer=result;
                runOnUiThread(() -> web.evaluateJavascript("window.receiveAI(" + JSONObject.quote(answer) + ")", null));
            }).start();
        }
    }
    @Override public void onBackPressed() { if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(web!=null) web.destroy(); super.onDestroy(); }
}
